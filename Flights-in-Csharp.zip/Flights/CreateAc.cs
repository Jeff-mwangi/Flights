﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Flights
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        SqlConnection Con = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\moses\source\repos\Flights\Flights.mdf;Integrated Security = True; Connect Timeout = 30");
        private void button2_Click(object sender, EventArgs e)
        {
            if(Pass.Text == ConfirmPass.Text)
            {
            Con.Open();
            string query = "insert into flights values('"+PassNo.Text+ "','" + FullName.Text + "','" + Pass.Text + "','" +gender+ "')";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("You have Created Your Account Successfully!!");
            Con.Close();
            }
            else
            {
                MessageBox.Show("Your Passwords Does Not Match");
                Pass.Text = "";
                ConfirmPass.Text = "";
            }
            

            LoginForm log = new LoginForm();
            log.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        
        private void label9_Click(object sender, EventArgs e)
        {
            LoginForm login = new LoginForm();
            login.Show();
            this.Hide();
        }
        string gender;
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Male";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Female";
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (Passcheck.Checked)
            {
                Pass.UseSystemPasswordChar = false;
            }
            else
            {
                Pass.UseSystemPasswordChar = true;
            }
        }
    }
}
