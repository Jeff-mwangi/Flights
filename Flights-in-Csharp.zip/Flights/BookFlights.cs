﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Flights
{
    public partial class BookFlights : Form
    {
        public BookFlights()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public void start()
        {
            var list = CultureInfo.GetCultures(CultureTypes.SpecificCultures).
            Select(p => new RegionInfo(p.Name).EnglishName).Distinct().OrderBy(s => s).ToList();
            from.DataSource = list;
        }
        public void destination()
        {
            var list = CultureInfo.GetCultures(CultureTypes.SpecificCultures).
            Select(p => new RegionInfo(p.Name).EnglishName).Distinct().OrderBy(s => s).ToList();
            to.DataSource = list;
        }
        private void BookFlights_Load(object sender, EventArgs e)
        {
            start();
            destination();
            datelabel.Text = DateTime.Today.Day.ToString() + "/" + DateTime.Today.Month.ToString() + "/" + DateTime.Today.Year.ToString();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        SqlConnection Con = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\moses\source\repos\Flights\Flights.mdf;Integrated Security = True; Connect Timeout = 30");

        private void button1_Click(object sender, EventArgs e)
        {
            Con.Open();
            string query = "insert into book values('"+from.Text+ "','" + to.Text + "','" + date.Text + "','" + time.Text + "')";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            Con.Close();
            MessageBox.Show("You have successfully Booked a Flight. See you And Keep Time. Pay when you get into the Airport!!!");
            MyFlights flights = new MyFlights();
            flights.Show();
            this.Hide();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            MyFlights mf = new MyFlights();
            mf.Show();
            this.Hide();
        }
    }
    }
