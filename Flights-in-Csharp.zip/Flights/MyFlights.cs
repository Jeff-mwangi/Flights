﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Flights
{
    public partial class MyFlights : Form
    {
        public MyFlights()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            LoginForm login = new LoginForm();
            login.Show();
            this.Hide();
        }
        SqlConnection Con = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\moses\source\repos\Flights\Flights.mdf;Integrated Security = True; Connect Timeout = 30");

        private void MyFlights_Load(object sender, EventArgs e)
        {
            Con.Open();
            
            string query = "select * from book";
            SqlDataAdapter adt = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(adt);
            var ds = new DataSet();
            adt.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0]; 

            Con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void add_Click(object sender, EventArgs e)
        {
            BookFlights flights = new BookFlights();
            flights.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            from.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            to.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            date.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            time.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            Con.Open();
            string query = "delete from book where from = " + from.Text + "";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Deleted Successfully");
            Con.Close();
            
        }
    }
}
