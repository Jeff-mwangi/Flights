﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Flights
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        SqlConnection Con = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\moses\source\repos\Flights\Flights.mdf;Integrated Security = True; Connect Timeout = 30");

        private void label9_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (PassNo.Text != "" && Pass.Text != "")
            {

                Con.Open();
                string query = "select * from flights where PassNo='" + PassNo.Text + "' and Pass = '" + Pass.Text + "'";
                SqlCommand cmd = new SqlCommand(query, Con);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                if (dr.Read() == true)
                {
                    BookFlights book = new BookFlights();
                    book.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Enter Correct PassPort No or Password");
                }
            }
            else
            {
                MessageBox.Show("Enter UserName or Password");
            }
            Con.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
